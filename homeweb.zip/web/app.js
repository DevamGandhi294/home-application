// Global variables
let deviceIP = '';
let isConnected = false;

// Show status message function
function showStatus(message, isError = false) {
    const statusElement = document.getElementById('statusMessage');
    statusElement.textContent = message;
    statusElement.style.backgroundColor = isError ? '#f44336' : '#333';
    statusElement.classList.add('show');
    setTimeout(() => {
        statusElement.classList.remove('show');
    }, 3000);
}

// Switch screen function
function showScreen(screenId) {
    document.querySelectorAll('.screen').forEach(screen => {
        screen.classList.add('hidden');
    });
    document.getElementById(screenId).classList.remove('hidden');
}

// Connect to device
async function connectToDevice() {
    const serialNumber = document.getElementById('serialNumber').value;
    if (!serialNumber) {
        showStatus('Please enter device serial number', true);
        return;
    }

    try {
        // Alert user to connect to device's WiFi
        alert(`Please connect your device's WiFi to: SmartRelay_${serialNumber}\nPassword: 12345678`);
        
        // Wait for user to connect to device WiFi
        if (confirm('Have you connected to the device WiFi?')) {
            const response = await fetch('http://192.168.4.1/info');
            const deviceInfo = await response.json();
            
            if (deviceInfo.serial === serialNumber) {
                isConnected = true;
                showScreen('wifiScreen');
                showStatus('Connected to device successfully');
            } else {
                showStatus('Invalid device serial number', true);
            }
        }
    } catch (error) {
        showStatus('Could not connect to device', true);
        console.error(error);
    }
}

// Configure WiFi
async function configureWiFi() {
    const ssid = document.getElementById('ssid').value;
    const password = document.getElementById('password').value;

    if (!ssid || !password) {
        showStatus('Please enter WiFi credentials', true);
        return;
    }

    try {
        const response = await fetch('http://192.168.4.1/configure', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `ssid=${encodeURIComponent(ssid)}&password=${encodeURIComponent(password)}`
        });

        if (response.ok) {
            showStatus('WiFi configuration saved');
            alert('Device will restart. Please connect your device back to your WiFi network.');
            // Wait for device to restart and connect
            setTimeout(findDevice, 30000);
        } else {
            showStatus('Failed to configure WiFi', true);
        }
    } catch (error) {
        showStatus('Could not configure WiFi', true);
        console.error(error);
    }
}

// Find device on network
async function findDevice() {
    try {
        const response = await fetch('http://192.168.4.1/info');
        const deviceInfo = await response.json();
        deviceIP = deviceInfo.ip;
        document.getElementById('deviceInfo').textContent = `Device IP: ${deviceIP}`;
        showScreen('controlScreen');
    } catch (error) {
        showStatus('Could not find device on network', true);
        console.error(error);
    }
}

// Control relay
async function controlRelay(command) {
    if (!deviceIP) {
        showStatus('Device IP not found', true);
        return;
    }

    try {
        const response = await fetch(`http://${deviceIP}/relay/${command}`);
        if (response.ok) {
            showStatus(`Relay turned ${command.toUpperCase()}`);
        } else {
            showStatus('Failed to control relay', true);
        }
    } catch (error) {
        showStatus('Could not connect to device', true);
        console.error(error);
    }
}